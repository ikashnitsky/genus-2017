################################################################################
#                                                                                                        
# Genus 2016. 14-11-2016
# Figure 1. TSR in 2003 and 2043 + change over 4 decades - map results
# Ilya Kashnitsky, ilya.kashnitsky@gmail.com
#                                                                                                    
################################################################################

# Erase all objects in memory
rm(list = ls(all = TRUE))

# load own functions
load('data0_supplementary/own_functions.RData')


load('geo_data/shp.n2eu28.all.RData')
load('data3_calculated/n2dec0342.RData')

basemap <- ik_map_eu.base()

bord <- fortify(Sborders)
fort <- fortify(Sn2, region = 'id') 

################################################################################
# maps TSR 2003 and 2042 - fixed color scales
df.tsr03 <- n2dec0342 %>%
        filter(as.numeric(year)%in%1)

fort.tsr03 <- suppressWarnings(left_join(x=fort, y=df.tsr03, by = 'id'))

tsr03 <- basemap +
        geom_polygon(data = gghole(fort.tsr03)[[1]], aes_string(x='long', y='lat', group='group', fill='tsr03'),
                     color='grey30',size=.1)+
        geom_polygon(data = gghole(fort.tsr03)[[2]], aes_string(x='long', y='lat', group='group', fill='tsr03'),
                     color='grey30',size=.1)+
        scale_fill_viridis('TSR\n2003',limits=c(.868,2.765))+
        geom_path(data=bord,aes(x=long, y=lat, group=group),color='grey20',size=.5)+
        guides(fill = guide_colorbar(barwidth = 1, barheight = 9))


load('data3_calculated/n2tsr43.RData')

fort.tsr43 <- suppressWarnings(left_join(x=fort, y=n2tsr43, by = 'id'))

tsr43 <- basemap +
        geom_polygon(data = gghole(fort.tsr43)[[1]], aes_string(x='long', y='lat', group='group', fill='tsr43'),
                     color='grey30',size=.1)+
        geom_polygon(data = gghole(fort.tsr43)[[2]], aes_string(x='long', y='lat', group='group', fill='tsr43'),
                     color='grey30',size=.1)+
        scale_fill_viridis('TSR\n2043',limits=c(.868,2.765))+
        geom_path(data=bord,aes(x=long, y=lat, group=group),color='grey20',size=.5)+
        guides(fill = guide_colorbar(barwidth = 1, barheight = 9))






################################################################################
# change maps 4 periods - fixed color scales

df.g1 <- n2dec0342 %>%
        filter(as.numeric(year)%in%1:10) %>%
        group_by(id) %>%
        select(2:8) %>%
        summarise_each(funs(sum))

fort.g1 <- suppressWarnings(left_join(x=fort, y=df.g1, by = 'id'))

g1 <- basemap +
        geom_polygon(data = gghole(fort.g1)[[1]], aes_string(x='long', y='lat', group='group', fill='g'),
                     color='grey30',size=.1)+
        geom_polygon(data = gghole(fort.g1)[[2]], aes_string(x='long', y='lat', group='group', fill='g'),
                     color='grey30',size=.1)+
        scale_fill_viridis('TSR change\n2003-2012',limits=c(-.7238,.3275))+
        geom_path(data=bord,aes(x=long, y=lat, group=group),color='grey20',size=.5)+
        guides(fill = guide_colorbar(barwidth = 1, barheight = 9))


df.g2 <- n2dec0342 %>%
        filter(as.numeric(year)%in%11:20) %>%
        group_by(id) %>%
        select(2:8) %>%
        summarise_each(funs(sum))

fort.g2 <- suppressWarnings(left_join(x=fort, y=df.g2, by = 'id'))

g2 <- basemap +
        geom_polygon(data = gghole(fort.g2)[[1]], aes_string(x='long', y='lat', group='group', fill='g'),
                     color='grey30',size=.1)+
        geom_polygon(data = gghole(fort.g2)[[2]], aes_string(x='long', y='lat', group='group', fill='g'),
                     color='grey30',size=.1)+
        scale_fill_viridis('TSR change\n2013-2022',limits=c(-.7238,.3275))+
        geom_path(data=bord,aes(x=long, y=lat, group=group),color='grey20',size=.5)+
        guides(fill = guide_colorbar(barwidth = 1, barheight = 9))


df.g3 <- n2dec0342 %>%
        filter(as.numeric(year)%in%21:30) %>%
        group_by(id) %>%
        select(2:8) %>%
        summarise_each(funs(sum))

fort.g3 <- suppressWarnings(left_join(x=fort, y=df.g3, by = 'id'))

g3 <- basemap +
        geom_polygon(data = gghole(fort.g3)[[1]], aes_string(x='long', y='lat', group='group', fill='g'),
                     color='grey30',size=.1)+
        geom_polygon(data = gghole(fort.g3)[[2]], aes_string(x='long', y='lat', group='group', fill='g'),
                     color='grey30',size=.1)+
        scale_fill_viridis('TSR change\n2023-2032',limits=c(-.7238,.3275))+
        geom_path(data=bord,aes(x=long, y=lat, group=group),color='grey20',size=.5)+
        guides(fill = guide_colorbar(barwidth = 1, barheight = 9))


df.g4 <- n2dec0342 %>%
        filter(as.numeric(year)%in%31:40) %>%
        group_by(id) %>%
        select(2:8) %>%
        summarise_each(funs(sum))

fort.g4 <- suppressWarnings(left_join(x=fort, y=df.g4, by = 'id'))

g4 <- basemap +
        geom_polygon(data = gghole(fort.g4)[[1]], aes_string(x='long', y='lat', group='group', fill='g'),
                     color='grey30',size=.1)+
        geom_polygon(data = gghole(fort.g4)[[2]], aes_string(x='long', y='lat', group='group', fill='g'),
                     color='grey30',size=.1)+
        scale_fill_viridis('TSR change\n2033-2042',limits=c(-.7238,.3275))+
        geom_path(data=bord,aes(x=long, y=lat, group=group),color='grey20',size=.5)+
        guides(fill = guide_colorbar(barwidth = 1, barheight = 9))






################################################################################
# align all 6 maps with arrows

list.plots <- list(tsr03,g1,g2,g3,g4,tsr43)


df.canvas <- data.frame(x=factor(sample(1:21,1000,replace = T)),
                 y=factor(sample(1:31,1000,replace = T)))

gg <- ggplot(df.canvas,aes(x=x,y=y))+
      
        annotation_custom(ggplotGrob(list.plots[[1]]),
                          xmin = 1,xmax = 11,ymin = 21,ymax = 31)+
        
        annotation_custom(ggplotGrob(list.plots[[2]]),
                          xmin = 12,xmax = 21,ymin = 21,ymax = 30)+
        annotation_custom(ggplotGrob(list.plots[[3]]),
                          xmin = 12,xmax = 21,ymin = 11.5,ymax = 20.5)+
        
        annotation_custom(ggplotGrob(list.plots[[4]]),
                          xmin = 1,xmax = 10,ymin = 11.5,ymax = 20.5)+
        annotation_custom(ggplotGrob(list.plots[[5]]),
                          xmin = 1,xmax = 10,ymin = 2,ymax = 11)+
        annotation_custom(ggplotGrob(list.plots[[6]]),
                          xmin = 11,xmax = 21,ymin = 1,ymax = 11)+
        
        coord_fixed(ratio = 1)+
        scale_x_discrete(expand = c(0, 0)) +
        scale_y_discrete(expand = c(0, 0)) +
        labs(x = NULL, y = NULL)+
        theme_map()+
        theme(aspect.ratio=3/2)


# DF with the coordinates of the 5 arrows
df.arrows <- data.frame(id=1:5,
                        x=c(11,12,12,10,10),
                        y=c(26,24,16,14,6),
                        xend=c(12,12,10,10,11),
                        yend=c(26,18,16,8,6))

# add arrows
gg <- gg + geom_curve(data = df.arrows %>% filter(id==1),
                      aes(x=x,y=y,xend=xend,yend=yend),
                      curvature = 0, 
                      arrow = arrow(type="closed",length = unit(0.25,"cm"))) +
        geom_curve(data = df.arrows %>% filter(id==2),
                   aes(x=x,y=y,xend=xend,yend=yend),
                   curvature = 0.3, 
                   arrow = arrow(type="closed",length = unit(0.25,"cm"))) +
        geom_curve(data = df.arrows %>% filter(id==3),
                   aes(x=x,y=y,xend=xend,yend=yend),
                   curvature = 0, 
                   arrow = arrow(type="closed",length = unit(0.25,"cm"))) +
        geom_curve(data = df.arrows %>% filter(id==4),
                   aes(x=x,y=y,xend=xend,yend=yend),
                   curvature = -0.3, 
                   arrow = arrow(type="closed",length = unit(0.25,"cm"))) +
        geom_curve(data = df.arrows %>% filter(id==5),
                   aes(x=x,y=y,xend=xend,yend=yend),
                   curvature = 0, 
                   arrow = arrow(type="closed",length = unit(0.25,"cm"))) 

# add labes
gg <- gg + annotate('text',label = LETTERS[1:6],
                    x=c(1,12,12,1,1,11)+.5,
                    y=c(30.5,29.5,20,20,10.5,10.5),
                    size=10,hjust=0, vjust=1)

ggsave('_output/fig1_maps_TSR_change_4decades.png',gg,width = 12,height = 18,dpi = 192)



###
# Report finish of the script execution
print('Done: script 3.01')
