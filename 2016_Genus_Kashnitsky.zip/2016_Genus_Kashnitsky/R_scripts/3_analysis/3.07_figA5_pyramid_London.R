################################################################################
#                                                                                                        
# Genus 2016. 14-11-2016
# Figure A5. Appendix. Population pyramids. London
# Ilya Kashnitsky, ilya.kashnitsky@gmail.com
#                                                                                                    
################################################################################

# Erase all objects in memory
rm(list = ls(all = TRUE))

# load own functions
load('data0_supplementary/own_functions.RData')



load('data2_prepared/n2p1.RData')
load('data2_prepared/n2p1proj.RData')

df.lon.obs <- filter(n2p1,id=='UKI1',age%in%c(paste0('a0',0:9),paste0('a',10:90)),sex!='b',year!='y2013') %>% 
        droplevels()
df.lon.proj <- filter(n2p1proj,id=='UKI1',age%in%c(paste0('a0',0:9),paste0('a',10:90)),sex!='total') %>%
        droplevels() %>%
        select(year,id,sex,age,value)


df.lon <- suppressWarnings(bind_rows(df.lon.obs,df.lon.proj))
df.lon$year <- factor(df.lon$year)

gg1 <- ik_gg_population.pyramid.compare(df = df.lon,t1 = 2003,t2 = 2013)
gg2 <- ik_gg_population.pyramid.compare(df = df.lon,t1 = 2013,t2 = 2023)
gg3 <- ik_gg_population.pyramid.compare(df = df.lon,t1 = 2023,t2 = 2033)
gg4 <- ik_gg_population.pyramid.compare(df = df.lon,t1 = 2033,t2 = 2043)


### RESOLUTION
# only 2003-2013 is reasonable to show

df.london <- filter(n2p1,id=='UKI1',age%in%c(paste0('a0',0:9),paste0('a',10:90)),sex!='b') %>% 
        droplevels()

# simulate age 90
a90 <- filter(df.london,age=='a89') %>%
        mutate(age='a90',
               value=.9*value)

df.london[is.null(df.london)] <- NA

df.london <- ik_dm_fill.missings(df.london,a90,by=c('year','id','sex','age'))



gg <- ik_gg_population.pyramid.compare(df = df.london,t1 = 2003,t2 = 2013)

ggsave('_output/figA5_pyramid_London.png',gg,width = 7, height = 7,dpi=192)


###
# Report finish of the script execution
print('Done: script 3.07')
