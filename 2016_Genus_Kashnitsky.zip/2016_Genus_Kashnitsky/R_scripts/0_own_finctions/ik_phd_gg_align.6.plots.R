################################################################################
#
# Genus 2016. 14-11-2016
# Function. Align decomposed plots neatly on A4 canvas
# Ilya Kashnitsky, ilya.kashnitsky@gmail.com
#
################################################################################


ik_phd_gg_align.6.plots <- function(list.plots, aspect.ratio=1, labels=LETTERS[1:6],labels.size=8){

        require(ggplot2)
        require(ggthemes)
        require(gridExtra)
        require(dplyr)


        df <- data.frame(x=factor(sample(1:21,1000,replace = T)),
                         y=factor(sample(1:31,1000,replace = T)))

        gg <- ggplot(df,aes(x=x,y=y))+

                annotation_custom(ggplotGrob(list.plots[[1]]),
                                  xmin = 1,xmax = 9,ymin = 22,ymax = 30)+

                annotation_custom(ggplotGrob(list.plots[[2]]),
                                  xmin = 13,xmax = 21,ymin = 20.5,ymax = 28.5)+
                annotation_custom(ggplotGrob(list.plots[[3]]),
                                  xmin = 13,xmax = 21,ymin = 11.5,ymax = 19.5)+

                annotation_custom(ggplotGrob(list.plots[[4]]),
                                  xmin = 1,xmax = 9,ymin = 10,ymax = 18)+
                annotation_custom(ggplotGrob(list.plots[[5]]),
                                  xmin = 1,xmax = 9,ymin = 1,ymax = 9)+
                annotation_custom(ggplotGrob(list.plots[[6]]),
                                  xmin = 13,xmax = 21,ymin = 1,ymax = 9)+

                coord_fixed(ratio = aspect.ratio)+
                scale_x_discrete(expand = c(0, 0)) +
                scale_y_discrete(expand = c(0, 0)) +
                labs(x = NULL, y = NULL)+
                theme_map()+
                theme(aspect.ratio=aspect.ratio*3/2)


        # DF with the coordinates of the 5 arrows
        df.arrows <- data.frame(id=1:5,
                                x=c(9,9,13,13,13),
                                y=c(22,22,11.5,11.5,11.5),
                                xend=c(13,13,9,9,13),
                                yend=c(21.5,18.5,11,8,8))

        # add arrows
        gg <- gg + geom_curve(data = df.arrows %>% filter(id==1),
                                  aes(x=x,y=y,xend=xend,yend=yend),
                                  curvature = 0.1,
                                  arrow = arrow(type="closed",length = unit(0.25,"cm"))) +
                geom_curve(data = df.arrows %>% filter(id==2),
                           aes(x=x,y=y,xend=xend,yend=yend),
                           curvature = -0.1,
                           arrow = arrow(type="closed",length = unit(0.25,"cm"))) +
                geom_curve(data = df.arrows %>% filter(id==3),
                           aes(x=x,y=y,xend=xend,yend=yend),
                           curvature = -0.15,
                           arrow = arrow(type="closed",length = unit(0.25,"cm"))) +
                geom_curve(data = df.arrows %>% filter(id==4),
                           aes(x=x,y=y,xend=xend,yend=yend),
                           curvature = 0,
                           arrow = arrow(type="closed",length = unit(0.25,"cm"))) +
                geom_curve(data = df.arrows %>% filter(id==5),
                           aes(x=x,y=y,xend=xend,yend=yend),
                           curvature = 0.3,
                           arrow = arrow(type="closed",length = unit(0.25,"cm")))

        # add labes
        gg <- gg + annotate('text',label = labels,
                            x=c(1,13,13,1,1,13)+.5,
                            y=c(30,28.5,19.5,18,9,9)+.1,
                            size=labels.size,hjust=0, vjust=0)

        return(gg)
}

